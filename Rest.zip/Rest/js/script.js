document.addEventListener('DOMContentLoaded', () => {
    const menuItemsGrid = document.querySelector('.menu-items-grid');
    const menuCategoriesContainer = document.querySelector('.menu-categories');
    const popularGrid = document.querySelector('.popular-grid');
    const favoritesGrid = document.querySelector('.favorites-grid');
    const bookingForm = document.getElementById('booking-form');
    const contactForm = document.getElementById('contact-form');
    const modal = document.getElementById('modal');
    const modalMessage = document.getElementById('modal-message');
    const modalClose = document.querySelector('.modal-close');
    let allMenuItems = [];

    // 1. Загрузка данных из JSON
    async function loadMenuData() {
        try {
            const response = await fetch('data/menu.json');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            allMenuItems = await response.json();
            displayMenuItems(allMenuItems);
            generateCategoryButtons(allMenuItems);
            displayPopularItems(allMenuItems);
            displayFavorites();
        } catch (error) {
            console.error('Ошибка загрузки меню:', error);
            menuItemsGrid.innerHTML = '<p>Не удалось загрузить меню. Пожалуйста, попробуйте позже.</p>';
        }
    }

    // 2. Отображение блюд
    function displayMenuItems(itemsToShow, container = menuItemsGrid) {
        container.innerHTML = '';
        if (itemsToShow.length === 0) {
            container.innerHTML = `<p>Нет блюд${container === favoritesGrid ? ' в избранном' : ' в этой категории'}.</p>`;
            return;
        }
        const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
        itemsToShow.forEach(item => {
            const isFavorite = favorites.includes(item.id);
            const menuItem = document.createElement('div');
            menuItem.classList.add('menu-item');
            menuItem.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div class="menu-item-content">
                    <h3>${item.name}</h3>
                    <p>${item.description}</p>
                    <span class="price">${item.price} ₽</span>
                    <button class="favorite-btn${isFavorite ? ' active' : ''}" data-id="${item.id}" aria-label="${isFavorite ? 'Убрать из избранного' : 'Добавить в избранное'}" aria-pressed="${isFavorite}">
                        ${isFavorite ? '★' : '☆'}
                    </button>
                </div>
            `;
            container.appendChild(menuItem);
        });
        addFavoriteListeners();
    }

    // 3. Генерация кнопок категорий
    function generateCategoryButtons(items) {
        const categories = ['Все', ...new Set(items.map(item => item.category))];
        categories.forEach(category => {
            const button = document.createElement('button');
            button.classList.add('menu-category-btn');
            button.textContent = category;
            button.dataset.category = category;
            button.setAttribute('aria-pressed', category === 'Все' ? 'true' : 'false');
            if (category === 'Все') {
                button.classList.add('active');
            }
            button.addEventListener('click', () => {
                document.querySelectorAll('.menu-category-btn').forEach(btn => {
                    btn.classList.remove('active');
                    btn.setAttribute('aria-pressed', 'false');
                });
                button.classList.add('active');
                button.setAttribute('aria-pressed', 'true');
                filterMenuItems(category);
            });
            button.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    button.click();
                }
            });
            menuCategoriesContainer.appendChild(button);
        });
    }

    // 4. Фильтрация блюд
    function filterMenuItems(category) {
        let filteredItems = category === 'Все' ? allMenuItems : allMenuItems.filter(item => item.category === category);
        displayMenuItems(filteredItems);
    }

    // 5. Отображение популярных блюд
    function displayPopularItems(items) {
        const popularItems = items.filter(item => item.popular);
        displayMenuItems(popularItems, popularGrid);
    }

    // 6. Отображение избранного
    function displayFavorites() {
        const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
        const favoriteItems = allMenuItems.filter(item => favorites.includes(item.id));
        displayMenuItems(favoriteItems, favoritesGrid);
    }

    // 7. Обновление состояния всех кнопок "Избранное"
    function updateFavoriteButtons(itemId, isFavorite) {
        document.querySelectorAll(`.favorite-btn[data-id="${itemId}"]`).forEach(btn => {
            btn.classList.toggle('active', isFavorite);
            btn.textContent = isFavorite ? '★' : '☆';
            btn.setAttribute('aria-label', isFavorite ? 'Убрать из избранного' : 'Добавить в избранное');
            btn.setAttribute('aria-pressed', isFavorite);
        });
    }

    // 8. Обработчик для кнопок "Избранное"
    function addFavoriteListeners() {
        document.querySelectorAll('.favorite-btn').forEach(btn => {
            // Удаляем старые обработчики, чтобы избежать дублирования
            btn.removeEventListener('click', handleFavoriteClick);
            btn.removeEventListener('keydown', handleFavoriteKeydown);

            btn.addEventListener('click', handleFavoriteClick);
            btn.addEventListener('keydown', handleFavoriteKeydown);
        });

        function handleFavoriteClick(e) {
            const btn = e.currentTarget;
            const itemId = parseInt(btn.dataset.id);
            let favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
            const isFavorite = favorites.includes(itemId);

            console.log(`Клик по блюду ${itemId}, текущее состояние: ${isFavorite ? 'в избранном' : 'не в избранном'}`);

            if (isFavorite) {
                favorites = favorites.filter(id => id !== itemId);
                console.log(`Удалено из избранного: ${itemId}`);
            } else {
                favorites.push(itemId);
                console.log(`Добавлено в избранное: ${itemId}`);
            }

            localStorage.setItem('favorites', JSON.stringify(favorites));
            updateFavoriteButtons(itemId, !isFavorite);
            displayFavorites();
        }

        function handleFavoriteKeydown(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                e.currentTarget.click();
            }
        }
    }

    // 9. Обработка формы бронирования
    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const name = formData.get('name');
        const date = formData.get('date');
        const time = formData.get('time');
        const guests = formData.get('guests');
        modalMessage.textContent = `Бронь на имя ${name} на ${date} в ${time} для ${guests} гостей подтверждена`;
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        bookingForm.reset();
    });

    // 10. Обработка формы обратной связи
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        modalMessage.textContent = 'Ваше сообщение отправлено! Мы свяжемся с вами скоро.';
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        contactForm.reset();
    });

    // 11. Закрытие модального окна
    modalClose.addEventListener('click', () => {
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
    });

    modal.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            modal.classList.remove('active');
            modal.setAttribute('aria-hidden', 'true');
        }
    });

    // Запускаем загрузку данных
    loadMenuData();
});